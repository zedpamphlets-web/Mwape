# SignSpeak ZM

An Expo / React Native starter app: camera-based sign capture → text →
speech through a Bluetooth speaker, with UI support for 8 Zambian
languages and a Lipila mobile-money payment screen.

## What actually works right now

- ✅ Expo Router-free tab navigation (Home / Sign / Language / Payment)
- ✅ **Real, working sign recognition** via Gemini's vision API — tap
  the record button and it continuously captures frames, sends each
  to Gemini, and appends whatever word/phrase it thinks it sees
- ✅ **Real-time speech** — each recognized sign is spoken out loud the
  moment it's detected, so it feels live rather than waiting for a
  finished sentence. After a ~2.5 second pause, the words spoken so far
  are also tidied into a proper sentence and shown on screen (text
  only, not re-spoken, so you don't hear it twice).
- ✅ Text-to-speech playback (`expo-speech`) — plays through whatever
  audio output is active, including a paired Bluetooth speaker (pairing
  itself happens in the phone's Bluetooth settings, not in-app)
- ✅ Language switcher with persistence (`AsyncStorage`) for all 8
  languages
- ✅ **Free trial + tiered pricing**, enforced in-app:
  - 2 days free, automatically, from first use
  - K30 / 6 days
  - K50 / 12 days
  - K100 / 20 days
  When the trial or plan runs out, the Sign screen shows a paywall that
  routes to the Payment tab. See the "Pricing" section below for the
  important caveat on this.
- ✅ Lipila payment screen wired to a REST client module

## Pricing enforcement — read this before you rely on it

`src/services/subscription.js` now tracks trial/plan status in
**Supabase** (a real backend) instead of only on the device — see the
Supabase setup section below. That fixes storage being wiped
client-side to erase history, but two gaps remain before you charge
real users at scale:

1. **Plan activation still trusts the client by default.** As shipped,
   `PaymentScreen.js` activates the plan as soon as the Lipila API call
   returns, without waiting for Lipila's webhook to confirm the money
   actually landed. A flaky network response could activate a plan
   that was never paid for, or miss one that was. The fix —
   `supabase/functions/lipila-webhook` — is included but **not wired
   up by default**; deploy it and switch activation to happen there
   instead (see Supabase setup section).
2. **The trial still resets on reinstall.** It's tied to a random
   device ID generated locally, not to something a user can't easily
   shed (phone number, account). Uninstalling / clearing app data gets
   a fresh trial. Tying it to the paying phone number, or adding real
   auth, closes this gap.

Neither of these matters for testing/demoing the app. Both matter
before you depend on this for revenue.

## What is still a placeholder / needs work before this is a real product

1. **Sign recognition is real but not trained for sign language.**
   `src/services/signRecognition.js` sends each camera frame to Gemini's
   general-purpose vision model and asks it to guess the sign — it has
   no special training on any signed language's grammar or handshapes.
   Expect it to do okay with slow, deliberate, held signs and to miss
   or misread a lot of real signing, especially fast/fluid sequences.
   See the comments at the bottom of that file for the path to a real
   trained model (on-device TensorFlow hand-pose model + your own
   classifier, or a hosted model you train yourself). Build that with
   Deaf community input on vocabulary and correctness, not solo.

2. **Free-tier rate limits.** Continuous capture calls the Gemini API
   roughly once per second while recording — that will burn through a
   free-tier daily/per-minute quota faster than occasional use. If you
   hit rate-limit errors, increase `CAPTURE_INTERVAL_MS` in
   `SignCaptureScreen.js`.

3. **Translations are incomplete on purpose.** `src/i18n/translations.js`
   has full English strings. The other 7 languages (Bemba, Nyanja,
   Tonga, Lozi, Kaonde, Lunda, Luvale) currently fall back to English
   for most strings — I'm not confident enough in my Bemba/Nyanja/
   Tonga/Lozi/Kaonde/Lunda/Luvale to put unverified UI text in front of
   real users of an accessibility app. Get each language reviewed by a
   native speaker before shipping.

4. **Text-to-speech pronunciation.** Phone TTS engines mostly don't
   ship Zambian-language voices yet, so spoken output currently uses
   an English voice reading whatever text is on screen. If exact
   pronunciation matters, look into a cloud TTS provider that supports
   these languages, or ship your own pre-recorded audio clips for a
   fixed phrase set.

5. **Lipila base URL and API key are placeholders.** Open
   `src/services/lipila.js` and:
   - Replace `LIPILA_BASE_URL` with the exact base URL from your
     Lipila dashboard/docs.
   - For real use, don't ship your Lipila API key inside the app —
     route payment requests through your own small backend that holds
     the real key, and point the app at your backend instead.

## AI (Gemini, free tier) — powers both recognition and cleanup

Two things run on your free Gemini key:

1. **Recognition** — each captured camera frame is sent to Gemini's
   vision endpoint to guess the sign (`src/services/signRecognition.js`).
2. **Cleanup** — once you pause signing, the accumulated words are sent
   to Gemini as text to turn into a natural sentence before speaking
   (`src/services/textCleanup.js`).

Both fail gracefully — if no key is set, or a request fails, recognition
just returns nothing for that frame and cleanup falls back to the raw
words, so the app never crashes because of this.

To turn it on:

1. Go to **aistudio.google.com**, sign in with a Google account.
2. Click **Get API key → Create API key** (no card needed, free tier).
3. Open `src/config.js` and paste your key into `GEMINI_API_KEY`.

Don't commit a real key to a public GitHub repo. For a private repo
it's fine to leave it in `config.js`; for a public repo, move it into
an environment variable instead (e.g. `expo-constants` + a `.env` file
listed in `.gitignore`) before pushing.

## Supabase setup (trial + plan tracking, backend-side)

1. Create a free project at **supabase.com**.
2. Go to **SQL Editor**, paste in the contents of `supabase/schema.sql`,
   and run it — this creates the `subscriptions` and `payments` tables.
3. Go to **Project Settings → API**, copy your **Project URL** and
   **anon public key**, and paste them into `src/config.js` as
   `SUPABASE_URL` and `SUPABASE_ANON_KEY`.
4. That's enough to run the app — trial/plan status now lives in
   Supabase instead of only on the device. If you skip this step
   entirely, the app quietly falls back to local-only tracking (same
   as before), so nothing breaks.

**Optional but recommended — the webhook (`supabase/functions/lipila-webhook`):**
Right now, `PaymentScreen.js` activates a plan as soon as Lipila's API
call returns, which trusts the client. The proper fix is in
`supabase/functions/lipila-webhook/index.ts` — a Supabase Edge Function
that only Lipila's own server calls once a payment is truly confirmed,
using your `service_role` key (never shipped in the app). Read the
comments at the top of that file before deploying it — Lipila's exact
webhook payload shape isn't confirmed here, so you'll need to check
their dashboard/docs and adjust field names + add signature
verification first. Deploy with:

```bash
supabase functions deploy lipila-webhook
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=your_service_role_key
```

Then set that function's URL as your Lipila webhook/callback URL.

## Design

The UI uses a glassmorphic look: a blue gradient backdrop
(`src/components/GlassScreen.js`) with frosted, translucent cards
(`src/components/GlassCard.js`) floating on top via `expo-blur`, plus a
translucent floating tab bar. To adjust the palette, edit
`src/theme/colors.js` — every screen pulls from there.

## Setup

```bash
npm install
npx expo start
```

Scan the QR code with Expo Go (iOS/Android) to run it on your phone.
Note: because the camera screen uses `expo-camera`, it works fine in
Expo Go. If you later add an on-device ML model (path 1 in
`signRecognition.js`), you'll need to switch to a Dev Client:

```bash
npx expo prebuild
npx expo run:android   # or run:ios
```

## Pushing to GitHub

```bash
cd signspeak-zm        # after unzipping
git init
git add .
git commit -m "Initial SignSpeak scaffold"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## Suggested next steps, in order

1. Partner with a Deaf community organization in Zambia for
   vocabulary priorities and feedback.
2. Get the 7 local-language translations reviewed/completed.
3. Pick a sign-recognition approach (see `signRecognition.js`) and
   start with a small fixed vocabulary (30–100 signs).
4. Fill in real Lipila credentials behind your own backend.
5. Test on real Bluetooth speakers across a few Android/iOS devices —
   Bluetooth audio routing behavior varies by phone.
