import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text } from 'react-native';
import { BlurView } from 'expo-blur';

import { LanguageProvider, useLanguage } from './src/i18n/LanguageContext';
import HomeScreen from './src/screens/HomeScreen';
import SignCaptureScreen from './src/screens/SignCaptureScreen';
import LanguageSettingsScreen from './src/screens/LanguageSettingsScreen';
import PaymentScreen from './src/screens/PaymentScreen';
import colors from './src/theme/colors';

const Tab = createBottomTabNavigator();

function Icon({ symbol }) {
  return <Text style={{ fontSize: 20 }}>{symbol}</Text>;
}

function GlassTabBackground() {
  return (
    <BlurView
      intensity={50}
      tint="dark"
      style={{
        flex: 1,
        borderTopWidth: 1,
        borderTopColor: colors.glassBorder,
      }}
    />
  );
}

function Tabs() {
  const { t } = useLanguage();
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.text,
        tabBarInactiveTintColor: colors.textFaint,
        tabBarStyle: { position: 'absolute', backgroundColor: 'transparent', elevation: 0 },
        tabBarBackground: () => <GlassTabBackground />,
      }}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: t.home, tabBarIcon: () => <Icon symbol="🏠" /> }}
      />
      <Tab.Screen
        name="Sign"
        component={SignCaptureScreen}
        options={{ title: t.appName, tabBarIcon: () => <Icon symbol="🤟" /> }}
      />
      <Tab.Screen
        name="Language"
        component={LanguageSettingsScreen}
        options={{ title: t.settings, tabBarIcon: () => <Icon symbol="🌍" /> }}
      />
      <Tab.Screen
        name="Payment"
        component={PaymentScreen}
        options={{ title: t.payment, tabBarIcon: () => <Icon symbol="💳" /> }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Tabs />
      </NavigationContainer>
    </LanguageProvider>
  );
}
