// supabase/functions/lipila-webhook/index.ts
//
// Deploy with: supabase functions deploy lipila-webhook
// Then set this URL as your Lipila webhook/callback URL in their
// dashboard, and point PaymentScreen's callbackUrl at it too (see
// src/services/lipila.js).
//
// This function uses the service_role key (set as a secret, never
// shipped in the app) so it can write to `subscriptions` regardless of
// RLS policies — this is the trusted path for activating plans, unlike
// the client writing directly with the anon key.
//
// ⚠️ Lipila's exact webhook payload shape and any signature/verification
// header aren't fully documented publicly as of this writing — check
// your Lipila dashboard/docs for the real field names and whether they
// sign requests, and adjust the parsing + verification below to match.
// Do not deploy this as-is without verifying the payload shape first —
// as written, it trusts whatever body is POSTed, which is NOT safe
// until you add real signature verification.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0';

const PLAN_DAYS: Record<string, number> = {
  plan6: 6,
  plan12: 12,
  plan20: 20,
};

Deno.serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Method not allowed', { status: 405 });
  }

  // TODO: verify a signature/secret header here once you confirm what
  // Lipila actually sends — reject the request if it doesn't match.
  // Without this, anyone who finds this URL could fake a "successful"
  // payment.

  const body = await req.json();

  // TODO: adjust these field names to match Lipila's real webhook
  // payload — these are placeholders based on the collection request
  // shape, not confirmed webhook field names.
  const referenceId = body.referenceId;
  const status = body.status; // expect something like "SUCCESSFUL" / "FAILED"

  if (!referenceId) {
    return new Response('Missing referenceId', { status: 400 });
  }

  const supabase = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  );

  const { data: payment, error: findError } = await supabase
    .from('payments')
    .select('*')
    .eq('lipila_reference', referenceId)
    .maybeSingle();

  if (findError || !payment) {
    return new Response('Payment record not found', { status: 404 });
  }

  const isSuccess = /success/i.test(status || '');

  await supabase
    .from('payments')
    .update({ status: isSuccess ? 'successful' : 'failed', updated_at: new Date().toISOString() })
    .eq('id', payment.id);

  if (isSuccess) {
    const days = PLAN_DAYS[payment.plan_id] ?? 0;
    const now = Date.now();

    const { data: sub } = await supabase
      .from('subscriptions')
      .select('plan_expires_at')
      .eq('device_id', payment.device_id)
      .maybeSingle();

    const base =
      sub?.plan_expires_at && new Date(sub.plan_expires_at).getTime() > now
        ? new Date(sub.plan_expires_at).getTime()
        : now;

    const expiresAt = new Date(base + days * 24 * 60 * 60 * 1000).toISOString();

    await supabase
      .from('subscriptions')
      .update({
        plan_id: payment.plan_id,
        plan_started_at: new Date(now).toISOString(),
        plan_expires_at: expiresAt,
        updated_at: new Date(now).toISOString(),
      })
      .eq('device_id', payment.device_id);
  }

  return new Response('OK', { status: 200 });
});
