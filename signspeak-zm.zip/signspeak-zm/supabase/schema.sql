-- schema.sql
--
-- Run this once in your Supabase project: Dashboard → SQL Editor →
-- paste this whole file → Run.

-- One row per device. device_id is a random UUID the app generates
-- once and stores locally (see src/services/subscription.js) — there's
-- no login, so this is the closest thing to a user identity right now.
create table if not exists subscriptions (
  device_id text primary key,
  trial_started_at timestamptz not null default now(),
  plan_id text,
  plan_started_at timestamptz,
  plan_expires_at timestamptz,
  updated_at timestamptz not null default now()
);

-- One row per payment attempt, so you have an audit trail independent
-- of whatever the subscriptions table currently says.
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  device_id text not null,
  phone_number text not null,
  plan_id text not null,
  amount numeric not null,
  lipila_reference text,
  status text not null default 'pending', -- pending | successful | failed
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Row Level Security -------------------------------------------------
-- IMPORTANT — read this before you ship:
--
-- These policies allow anyone with your public anon key (i.e. anyone
-- who has the app installed) to read and write ANY row in these
-- tables, not just their own device's row. That's fine for testing —
-- it is NOT fine for production, because a malicious user could grant
-- themselves a free plan by writing directly to the table with the
-- anon key, bypassing payment entirely.
--
-- Before real launch, do ONE of:
--   a) Remove the app's direct write access to `subscriptions`
--      entirely (make it read-only for anon), and only ever write to
--      it from the lipila-webhook Edge Function using the
--      service_role key (which bypasses RLS and is never exposed to
--      the app). This is the recommended fix — see
--      supabase/functions/lipila-webhook/index.ts.
--   b) Add Supabase Auth so each device/user has a real identity, and
--      scope policies to `auth.uid()` instead of a client-supplied
--      device_id (a client-supplied id can't be trusted for security
--      decisions on its own).

alter table subscriptions enable row level security;
alter table payments enable row level security;

-- Demo-permissive policies (tighten before production — see above).
create policy "anon can read subscriptions" on subscriptions
  for select using (true);

create policy "anon can upsert subscriptions" on subscriptions
  for insert with check (true);

create policy "anon can update subscriptions" on subscriptions
  for update using (true);

create policy "anon can insert payments" on payments
  for insert with check (true);

create policy "anon can read own payments" on payments
  for select using (true);

-- The Edge Function uses the service_role key, which bypasses RLS
-- entirely, so it can always update payment status regardless of
-- these policies.
