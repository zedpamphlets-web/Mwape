import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import GlassScreen from '../components/GlassScreen';
import GlassCard from '../components/GlassCard';
import { useLanguage } from '../i18n/LanguageContext';
import colors from '../theme/colors';

export default function HomeScreen({ navigation }) {
  const { t } = useLanguage();

  return (
    <GlassScreen style={styles.container}>
      <View style={styles.spacer} />

      <GlassCard style={styles.heroCard}>
        <Text style={styles.appName}>{t.appName}</Text>
        <Text style={styles.title}>{t.welcomeTitle}</Text>
        <Text style={styles.body}>{t.welcomeBody}</Text>

        <TouchableOpacity
          style={styles.primaryButton}
          onPress={() => navigation.navigate('Sign')}
        >
          <Text style={styles.primaryButtonText}>{t.startSigning}</Text>
        </TouchableOpacity>
      </GlassCard>

      <Text style={styles.hint}>{t.bluetoothHint}</Text>

      <View style={styles.spacer} />
    </GlassScreen>
  );
}

const styles = StyleSheet.create({
  container: { padding: 24, paddingBottom: 110, justifyContent: 'center' },
  spacer: { flex: 1 },
  heroCard: { marginBottom: 20 },
  appName: {
    fontSize: 13,
    fontWeight: '700',
    color: colors.textFaint,
    letterSpacing: 2,
    textTransform: 'uppercase',
    marginBottom: 14,
  },
  title: {
    fontSize: 26,
    fontWeight: '700',
    color: colors.text,
    marginBottom: 12,
  },
  body: {
    fontSize: 15,
    color: colors.textMuted,
    lineHeight: 22,
    marginBottom: 24,
  },
  primaryButton: {
    backgroundColor: colors.text,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: colors.onGlassText,
    fontSize: 16,
    fontWeight: '700',
  },
  hint: {
    fontSize: 13,
    color: colors.textFaint,
    textAlign: 'center',
    paddingHorizontal: 12,
  },
});
