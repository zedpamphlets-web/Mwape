import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import GlassScreen from '../components/GlassScreen';
import GlassCard from '../components/GlassCard';
import { useLanguage } from '../i18n/LanguageContext';
import colors from '../theme/colors';

export default function LanguageSettingsScreen() {
  const { t, code, setLanguage, languages } = useLanguage();

  return (
    <GlassScreen style={styles.container}>
      <Text style={styles.title}>{t.selectLanguage}</Text>
      <FlatList
        data={languages}
        keyExtractor={(item) => item.code}
        contentContainerStyle={{ paddingBottom: 120 }}
        renderItem={({ item }) => {
          const active = item.code === code;
          return (
            <TouchableOpacity onPress={() => setLanguage(item.code)} style={styles.rowWrap}>
              <GlassCard
                style={styles.row}
                intensity={active ? 55 : 30}
              >
                <View style={styles.rowInner}>
                  <Text style={[styles.rowText, active && styles.rowTextActive]}>
                    {item.label}
                  </Text>
                  {active && <Text style={styles.check}>✓</Text>}
                </View>
              </GlassCard>
            </TouchableOpacity>
          );
        }}
      />
    </GlassScreen>
  );
}

const styles = StyleSheet.create({
  container: { padding: 20 },
  title: { fontSize: 22, fontWeight: '700', color: colors.text, marginBottom: 16 },
  rowWrap: { marginBottom: 10 },
  row: { padding: 0 },
  rowInner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  rowText: { fontSize: 16, color: colors.text, fontWeight: '600' },
  rowTextActive: { color: colors.text },
  check: { color: colors.text, fontSize: 18, fontWeight: '800' },
});
