import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import GlassScreen from '../components/GlassScreen';
import GlassCard from '../components/GlassCard';
import { useLanguage } from '../i18n/LanguageContext';
import { createMobileMoneyCollection } from '../services/lipila';
import { PLANS, activatePlan, getAccessStatus, getDeviceId } from '../services/subscription';
import colors from '../theme/colors';

export default function PaymentScreen() {
  const { t } = useLanguage();
  const [phone, setPhone] = useState('');
  const [selectedPlan, setSelectedPlan] = useState(PLANS[0].id);
  const [status, setStatus] = useState('idle'); // idle | processing | success | error
  const [access, setAccess] = useState(null);

  const refreshAccess = useCallback(() => {
    getAccessStatus().then(setAccess);
  }, []);

  useFocusEffect(refreshAccess);

  const plan = PLANS.find((p) => p.id === selectedPlan);

  const handlePay = async () => {
    if (!phone || phone.length < 9) {
      Alert.alert(t.enterPhoneNumber);
      return;
    }
    setStatus('processing');
    try {
      const collection = await createMobileMoneyCollection({
        amount: plan.price,
        phoneNumber: phone,
      });
      const deviceId = await getDeviceId();
      await activatePlan(plan.id, {
        deviceId,
        phoneNumber: phone,
        lipilaReference: collection?.referenceId,
      });
      setStatus('success');
      refreshAccess();
    } catch (err) {
      console.warn('Lipila payment error:', err?.message);
      setStatus('error');
    }
  };

  return (
    <GlassScreen>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 120 }}>
        <GlassCard>
          <Text style={styles.title}>{t.subscriptionTitle}</Text>
          <Text style={styles.body}>{t.subscriptionBody}</Text>

          {access && (
            <View style={styles.statusPill}>
              <Text style={styles.statusPillText}>
                {access.hasAccess
                  ? `${access.reason === 'trial' ? t.trialActive : t.planActive} · ${access.daysLeft} ${t.daysLeft}`
                  : t.noAccess}
              </Text>
            </View>
          )}

          <View style={styles.plans}>
            {PLANS.map((p) => {
              const active = p.id === selectedPlan;
              return (
                <TouchableOpacity
                  key={p.id}
                  style={[styles.planCard, active && styles.planCardActive]}
                  onPress={() => setSelectedPlan(p.id)}
                >
                  <Text style={[styles.planDays, active && styles.planTextActive]}>
                    {p.days} {t.days}
                  </Text>
                  <Text style={[styles.planPrice, active && styles.planTextActive]}>
                    K{p.price}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          <Text style={styles.label}>{t.enterPhoneNumber}</Text>
          <TextInput
            style={styles.input}
            placeholder="260 97X XXX XXX"
            placeholderTextColor={colors.textFaint}
            keyboardType="phone-pad"
            value={phone}
            onChangeText={setPhone}
          />

          <TouchableOpacity
            style={styles.payButton}
            onPress={handlePay}
            disabled={status === 'processing'}
          >
            {status === 'processing' ? (
              <ActivityIndicator color={colors.onGlassText} />
            ) : (
              <Text style={styles.payButtonText}>
                {t.payNow} — K{plan.price}
              </Text>
            )}
          </TouchableOpacity>

          {status === 'success' && (
            <Text style={styles.successText}>{t.paymentSuccess}</Text>
          )}
          {status === 'error' && (
            <Text style={styles.errorText}>{t.paymentFailed}</Text>
          )}
        </GlassCard>
      </ScrollView>
    </GlassScreen>
  );
}

const styles = StyleSheet.create({
  title: { fontSize: 22, fontWeight: '700', color: colors.text, marginBottom: 8 },
  body: { fontSize: 15, color: colors.textMuted, marginBottom: 12, lineHeight: 20 },
  statusPill: {
    alignSelf: 'flex-start',
    backgroundColor: colors.glassFillStrong,
    borderRadius: 20,
    paddingHorizontal: 14,
    paddingVertical: 8,
    marginBottom: 20,
  },
  statusPillText: { color: colors.text, fontWeight: '700', fontSize: 13 },
  plans: { flexDirection: 'row', gap: 10, marginBottom: 24 },
  planCard: {
    flex: 1,
    borderWidth: 1,
    borderColor: colors.glassBorder,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    backgroundColor: colors.glassFill,
  },
  planCardActive: {
    borderColor: colors.text,
    backgroundColor: colors.glassFillStrong,
  },
  planDays: { fontSize: 13, color: colors.textMuted, fontWeight: '600', marginBottom: 6 },
  planPrice: { fontSize: 20, fontWeight: '800', color: colors.text },
  planTextActive: { color: colors.text },
  label: { fontSize: 14, fontWeight: '600', color: colors.textMuted, marginBottom: 8 },
  input: {
    borderWidth: 1,
    borderColor: colors.glassBorder,
    borderRadius: 14,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 16,
    marginBottom: 20,
    backgroundColor: colors.glassFill,
    color: colors.text,
  },
  payButton: {
    backgroundColor: colors.text,
    borderRadius: 16,
    paddingVertical: 16,
    alignItems: 'center',
  },
  payButtonText: { color: colors.onGlassText, fontSize: 16, fontWeight: '700' },
  successText: { color: colors.success, marginTop: 16, fontWeight: '600', textAlign: 'center' },
  errorText: { color: colors.danger, marginTop: 16, fontWeight: '600', textAlign: 'center' },
});
