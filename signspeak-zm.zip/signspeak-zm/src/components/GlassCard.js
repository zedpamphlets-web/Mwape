import React from 'react';
import { View, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import colors from '../theme/colors';

/**
 * A frosted-glass card: blurred translucent background, thin light
 * border, soft rounded corners. Use as a drop-in replacement for a
 * plain <View> card anywhere in the app.
 */
export default function GlassCard({ children, style, intensity = 40 }) {
  return (
    <View style={[styles.wrap, style]}>
      <BlurView intensity={intensity} tint="light" style={StyleSheet.absoluteFill} />
      <View style={styles.tint} pointerEvents="none" />
      <View style={styles.content}>{children}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: colors.glassBorder,
  },
  tint: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.glassFill,
  },
  content: {
    padding: 20,
  },
});
