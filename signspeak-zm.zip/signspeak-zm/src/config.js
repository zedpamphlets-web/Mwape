// config.js — fill these in yourself. Do not commit real keys to a public
// GitHub repo (this file is fine for a personal/private repo, but for
// anything public move these into environment variables instead, e.g.
// with `expo-constants` + a `.env` file that's in .gitignore).

export const GEMINI_API_KEY = 'PASTE_YOUR_FREE_GEMINI_API_KEY_HERE';

// Free-tier model as of this writing. Google renames/retires free models
// occasionally — if you get a 404, open aistudio.google.com, check which
// model is currently free, and update this string to match.
export const GEMINI_MODEL = 'gemini-2.5-flash';

// Supabase — create a free project at supabase.com, then go to
// Project Settings → API to find these two values. The anon key is
// safe to ship in the app (that's what it's for); never put your
// service_role key in the app — that one only belongs in the Edge
// Function (see supabase/functions/lipila-webhook).
export const SUPABASE_URL = 'PASTE_YOUR_SUPABASE_PROJECT_URL_HERE';
export const SUPABASE_ANON_KEY = 'PASTE_YOUR_SUPABASE_ANON_KEY_HERE';
