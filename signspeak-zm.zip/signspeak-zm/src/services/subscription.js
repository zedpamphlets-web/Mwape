// subscription.js — trial + plan status, backed by Supabase.
//
// Identity model: since this app has no login screen, each install
// generates a random device_id once (stored locally) and uses that as
// the row key in Supabase's `subscriptions` table. This means a
// reinstall / cleared app storage gets a fresh device_id and therefore
// a fresh free trial — see supabase/schema.sql for how to close that
// gap later (real auth, or tie identity to the paying phone number).
//
// If Supabase isn't configured yet (src/config.js still has the
// placeholder URL/key), everything here falls back to local-only
// AsyncStorage behavior so the app keeps working while you set it up.

import 'react-native-get-random-values';
import { v4 as uuidv4 } from 'uuid';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { supabase, supabaseConfigured } from './supabaseClient';

const DEVICE_ID_KEY = 'signspeak.deviceId';
const LOCAL_FALLBACK_KEY = 'signspeak.subscription.local';
const DAY_MS = 24 * 60 * 60 * 1000;
const TRIAL_DAYS = 2;

export const PLANS = [
  { id: 'plan6', days: 6, price: 30 },
  { id: 'plan12', days: 12, price: 50 },
  { id: 'plan20', days: 20, price: 100 },
];

export async function getDeviceId() {
  let id = await AsyncStorage.getItem(DEVICE_ID_KEY);
  if (!id) {
    id = uuidv4();
    await AsyncStorage.setItem(DEVICE_ID_KEY, id);
  }
  return id;
}

// --- Local-only fallback (used if Supabase isn't set up yet) --------

async function readLocal() {
  const raw = await AsyncStorage.getItem(LOCAL_FALLBACK_KEY);
  if (!raw) return { trialStartedAt: null, activePlan: null };
  try {
    return JSON.parse(raw);
  } catch {
    return { trialStartedAt: null, activePlan: null };
  }
}

async function writeLocal(state) {
  await AsyncStorage.setItem(LOCAL_FALLBACK_KEY, JSON.stringify(state));
}

async function ensureTrialStartedLocal() {
  const state = await readLocal();
  if (!state.trialStartedAt) {
    state.trialStartedAt = Date.now();
    await writeLocal(state);
  }
  return state;
}

async function getAccessStatusLocal() {
  const state = await ensureTrialStartedLocal();
  const now = Date.now();
  const trialEndsAt = state.trialStartedAt + TRIAL_DAYS * DAY_MS;

  if (now < trialEndsAt) {
    return { hasAccess: true, reason: 'trial', daysLeft: Math.ceil((trialEndsAt - now) / DAY_MS) };
  }
  if (state.activePlan && now < state.activePlan.expiresAt) {
    return {
      hasAccess: true,
      reason: 'plan',
      daysLeft: Math.ceil((state.activePlan.expiresAt - now) / DAY_MS),
    };
  }
  return { hasAccess: false, reason: 'none', daysLeft: 0 };
}

async function activatePlanLocal(planId) {
  const plan = PLANS.find((p) => p.id === planId);
  if (!plan) throw new Error(`Unknown plan: ${planId}`);
  const state = await readLocal();
  const now = Date.now();
  const base = state.activePlan && state.activePlan.expiresAt > now ? state.activePlan.expiresAt : now;
  state.activePlan = { id: plan.id, expiresAt: base + plan.days * DAY_MS };
  await writeLocal(state);
  return state.activePlan;
}

// --- Supabase-backed implementation ----------------------------------

async function ensureRowExists(deviceId) {
  // Insert a fresh row only if one doesn't already exist for this
  // device. Relies on device_id being the primary key.
  const { error } = await supabase
    .from('subscriptions')
    .insert({ device_id: deviceId, trial_started_at: new Date().toISOString() })
    .select()
    .single();

  // Error code 23505 = unique_violation, i.e. row already exists —
  // that's expected on every call after the first, not a real error.
  if (error && error.code !== '23505') {
    console.warn('Supabase ensureRowExists error:', error.message);
  }
}

async function fetchRow(deviceId) {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('device_id', deviceId)
    .maybeSingle();

  if (error) {
    console.warn('Supabase fetchRow error:', error.message);
    return null;
  }
  return data;
}

async function getAccessStatusSupabase() {
  const deviceId = await getDeviceId();
  await ensureRowExists(deviceId);
  const row = await fetchRow(deviceId);

  if (!row) {
    // Network hiccup or misconfiguration — fail open to local state
    // rather than locking the person out entirely.
    return getAccessStatusLocal();
  }

  const now = Date.now();
  const trialEndsAt = new Date(row.trial_started_at).getTime() + TRIAL_DAYS * DAY_MS;

  if (now < trialEndsAt) {
    return { hasAccess: true, reason: 'trial', daysLeft: Math.ceil((trialEndsAt - now) / DAY_MS) };
  }

  if (row.plan_expires_at) {
    const expiresAt = new Date(row.plan_expires_at).getTime();
    if (now < expiresAt) {
      return { hasAccess: true, reason: 'plan', daysLeft: Math.ceil((expiresAt - now) / DAY_MS) };
    }
  }

  return { hasAccess: false, reason: 'none', daysLeft: 0 };
}

/**
 * Records the payment attempt and, for this demo build, activates the
 * plan directly from the client once Lipila's collection call returns.
 *
 * ⚠️ See supabase/schema.sql and supabase/functions/lipila-webhook —
 * for real money, plan activation should happen from the webhook once
 * Lipila confirms the payment actually succeeded, not from this
 * client-side call. This still writes the plan so the app is fully
 * testable end-to-end before you wire up the webhook.
 */
async function activatePlanSupabase(planId, { deviceId, phoneNumber, lipilaReference } = {}) {
  const plan = PLANS.find((p) => p.id === planId);
  if (!plan) throw new Error(`Unknown plan: ${planId}`);

  const id = deviceId || (await getDeviceId());
  const row = await fetchRow(id);
  const now = Date.now();

  const base =
    row?.plan_expires_at && new Date(row.plan_expires_at).getTime() > now
      ? new Date(row.plan_expires_at).getTime()
      : now;

  const expiresAt = new Date(base + plan.days * DAY_MS).toISOString();

  const { error: subError } = await supabase
    .from('subscriptions')
    .update({
      plan_id: plan.id,
      plan_started_at: new Date(now).toISOString(),
      plan_expires_at: expiresAt,
      updated_at: new Date(now).toISOString(),
    })
    .eq('device_id', id);

  if (subError) console.warn('Supabase activatePlan error:', subError.message);

  const { error: paymentError } = await supabase.from('payments').insert({
    device_id: id,
    phone_number: phoneNumber || '',
    plan_id: plan.id,
    amount: plan.price,
    lipila_reference: lipilaReference || null,
    status: 'successful',
  });

  if (paymentError) console.warn('Supabase payment log error:', paymentError.message);

  return { id: plan.id, expiresAt };
}

// --- Public API (auto-picks Supabase if configured, else local) -----

export async function getAccessStatus() {
  if (!supabaseConfigured()) return getAccessStatusLocal();
  return getAccessStatusSupabase();
}

export async function activatePlan(planId, extra) {
  if (!supabaseConfigured()) return activatePlanLocal(planId);
  return activatePlanSupabase(planId, extra);
}

export default { PLANS, getAccessStatus, activatePlan, getDeviceId };
