// lipila.js — Lipila payment gateway integration (mobile money, Zambia)
//
// There is no official React Native SDK for Lipila (only an official
// Flutter SDK exists at the time of writing). This wraps their REST API
// directly with axios, using the same request/response shape as the
// Flutter SDK's CollectionRequest/CollectionResponse, so it should map
// cleanly if you ever swap this for an official RN SDK later.
//
// SETUP — you must fill these in before payments will work:
//   1. Sign up at the Lipila dashboard and get your API key.
//      Sandbox keys start with "lsk_", production keys with "lpk_".
//   2. Set LIPILA_BASE_URL below to the base URL shown in your Lipila
//      dashboard/API docs (not guessed here on purpose — paste the
//      exact one from your account so requests actually hit the right
//      host).
//   3. NEVER ship your API key inside the app bundle for production —
//      mobile app builds can be decompiled. Instead, create a small
//      backend endpoint (even a single serverless function) that holds
//      the real Lipila key and forwards collection requests. Point
//      LIPILA_BASE_URL at your own backend instead of Lipila directly
//      once you're ready for production.

import axios from 'axios';

const LIPILA_BASE_URL = 'https://REPLACE-WITH-YOUR-LIPILA-OR-BACKEND-BASE-URL';
const LIPILA_API_KEY = 'lsk_your_sandbox_key'; // sandbox key for dev only

const client = axios.create({
  baseURL: LIPILA_BASE_URL,
  timeout: 20000,
  headers: {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${LIPILA_API_KEY}`,
  },
});

/**
 * Kick off a mobile money collection (MTN / Airtel / Zamtel Money).
 * @param {object} params
 * @param {number} params.amount - amount in ZMW
 * @param {string} params.phoneNumber - customer's mobile money number, e.g. "260977123456"
 * @param {string} [params.reference] - your own order/subscription reference
 * @param {string} [params.callbackUrl] - webhook URL Lipila will notify on completion
 */
export async function createMobileMoneyCollection({
  amount,
  phoneNumber,
  reference = `SIGNSPEAK-${Date.now()}`,
  callbackUrl,
}) {
  const payload = {
    referenceId: reference,
    amount,
    accountNumber: phoneNumber,
    currency: 'ZMW',
    callbackUrl,
  };

  const { data } = await client.post('/collections', payload);
  return data; // { referenceId, status, paymentType, ... }
}

/**
 * Poll the status of a previously created collection.
 * @param {string} referenceId
 */
export async function getCollectionStatus(referenceId) {
  const { data } = await client.get(`/collections/${referenceId}`);
  return data;
}

/**
 * Check wallet balance (useful for an admin/dev screen, not end users).
 */
export async function getBalance() {
  const { data } = await client.get('/balance');
  return data;
}

export default {
  createMobileMoneyCollection,
  getCollectionStatus,
  getBalance,
};
