import * as Speech from 'expo-speech';

// NOTE: Phone operating systems ship a limited set of built-in TTS voices,
// and most don't include Bemba/Nyanja/Tonga/Lozi/Kaonde/Lunda/Luvale voices
// yet. We fall back to an English voice so speech still plays — the text
// on screen will be correct, but pronunciation of non-English words may
// be rough until a Zambian-language TTS voice/engine is integrated
// (e.g. a cloud TTS API that supports these languages).
const LOCALE_MAP = {
  en: 'en-US',
  bem: 'en-US',
  nya: 'en-US',
  toi: 'en-US',
  loz: 'en-US',
  kde: 'en-US',
  lun: 'en-US',
  lue: 'en-US',
};

export function speak(text, languageCode = 'en', options = {}) {
  if (!text) return;
  Speech.stop();
  Speech.speak(text, {
    language: LOCALE_MAP[languageCode] || 'en-US',
    pitch: 1.0,
    rate: 0.95,
    ...options,
  });
}

export function stopSpeaking() {
  Speech.stop();
}

export async function isSpeaking() {
  return Speech.isSpeakingAsync();
}
