// supabaseClient.js
import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from '../config';

// This app doesn't use Supabase Auth (no login screens) — it only uses
// the anon key to read/write the `subscriptions` table directly, so
// session persistence is turned off. See supabase/schema.sql for the
// table + Row Level Security setup, and its comments for why this is
// fine for a demo but should be tightened before real launch.
export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: false,
    autoRefreshToken: false,
    detectSessionInUrl: false,
  },
});

export function supabaseConfigured() {
  return (
    SUPABASE_URL &&
    !SUPABASE_URL.startsWith('PASTE_YOUR') &&
    SUPABASE_ANON_KEY &&
    !SUPABASE_ANON_KEY.startsWith('PASTE_YOUR')
  );
}

export default supabase;
