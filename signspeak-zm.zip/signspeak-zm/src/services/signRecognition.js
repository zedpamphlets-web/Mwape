// signRecognition.js
//
// REAL recognition using Gemini's vision (multimodal) capability — it
// looks at each camera frame and guesses the sign/gesture as a short
// phrase. This is a genuine, working integration, but read this
// honestly before you rely on it:
//
// - This is NOT a trained sign-language model. Gemini has no special
//   training on ASL, Zambian sign language, or any signed language's
//   grammar/handshapes. It's a general vision model doing its best
//   guess at a still image, one frame at a time.
// - It will work best with DELIBERATE, HELD, static-ish signs held
//   for ~1 second, and will regularly misread fast or fluid signing,
//   facial-grammar-dependent signs, and anything ambiguous.
// - Every frame costs one Gemini API call. The free tier has a
//   requests-per-minute cap, so this loop deliberately paces itself
//   (see SignCaptureScreen.js) rather than capturing as fast as
//   possible.
// - For a real product, this should be replaced with (or paired with)
//   an actual trained model — see the notes at the bottom of this file
//   for that upgrade path, and build it with Deaf community input on
//   vocabulary and correctness.

import { GEMINI_API_KEY, GEMINI_MODEL } from '../config';

const ENDPOINT = (model) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

const RECOGNITION_PROMPT = [
  'You are looking at one still frame from a live camera feed of a',
  'person signing in sign language. Identify the single hand sign or',
  'gesture shown, if any, as ONE short word or short phrase (max 3',
  'words) from everyday vocabulary — e.g. hello, thank you, help, yes,',
  'no, water, hungry, stop, please, sorry, good, more, finished, name,',
  'where, food, friend.',
  '',
  'If no clear, deliberate hand sign is visible — hand resting, out of',
  'frame, blurry, or mid-motion with no recognizable shape — respond',
  'with exactly: NONE',
  '',
  'Respond with ONLY the word/phrase or NONE. No punctuation, quotes,',
  'or explanation.',
].join('\n');

/**
 * @param {string} base64Image - JPEG frame, base64-encoded (no data: prefix)
 * @returns {Promise<{ sign: string, confidence: number } | null>}
 */
export async function recognizeFrame(base64Image) {
  if (!base64Image) return null;

  const keyLooksUnset = !GEMINI_API_KEY || GEMINI_API_KEY.startsWith('PASTE_YOUR');
  if (keyLooksUnset) {
    console.warn('Gemini API key not set in src/config.js — recognition disabled.');
    return null;
  }

  try {
    const response = await fetch(`${ENDPOINT(GEMINI_MODEL)}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              { text: RECOGNITION_PROMPT },
              { inline_data: { mime_type: 'image/jpeg', data: base64Image } },
            ],
          },
        ],
        generationConfig: { temperature: 0.2, maxOutputTokens: 20 },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.warn('Gemini vision request failed:', response.status, errText);
      return null;
    }

    const data = await response.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();

    if (!text || /^none$/i.test(text)) return null;

    return { sign: text, confidence: 0.6 };
  } catch (err) {
    console.warn('Gemini vision request error:', err?.message);
    return null;
  }
}

// ---------------------------------------------------------------------
// Upgrade path to a REAL trained sign-language model, when you're ready:
//
// 1) On-device model (works offline, needs a Dev Client not Expo Go):
//    @tensorflow/tfjs-react-native + @tensorflow-models/hand-pose-detection
//    for 21-point hand landmarks, feeding a small classifier you train
//    on a fixed vocabulary (30-100 signs to start).
//
// 2) Your own hosted cloud model (e.g. trained on Roboflow / Vertex AI
//    with a Mediapipe + classifier pipeline) instead of general-purpose
//    Gemini vision — far more accurate once you have training data.
//
// 3) Narrow scope first: fingerspelling (the manual alphabet) is much
//    easier to recognize reliably than full sign vocabulary, and lets
//    users spell any word letter by letter as a solid v1.
// ---------------------------------------------------------------------
