// textCleanup.js — turns the raw recognized-sign words into a natural
// sentence, in the user's selected language, using the free Google
// Gemini API.
//
// Get a free key (no credit card) at https://aistudio.google.com →
// "Get API key", then paste it into src/config.js as GEMINI_API_KEY.

import { GEMINI_API_KEY, GEMINI_MODEL } from '../config';

const ENDPOINT = (model) =>
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;

const LANGUAGE_NAMES = {
  en: 'English',
  bem: 'Bemba',
  nya: 'Nyanja',
  toi: 'Tonga',
  loz: 'Lozi',
  kde: 'Kaonde',
  lun: 'Lunda',
  lue: 'Luvale',
};

/**
 * Turn a list of recognized sign words into one natural sentence.
 * Falls back to a plain space-joined string (unchanged) if the API
 * key hasn't been set up yet, or if the request fails for any reason
 * — so the app keeps working even without Gemini configured.
 *
 * @param {string[]} words - raw recognized words/signs, in order
 * @param {string} languageCode - one of the LANGUAGE_NAMES keys
 * @returns {Promise<string>}
 */
export async function cleanUpSentence(words, languageCode = 'en') {
  const rawText = words.join(' ');
  if (!rawText.trim()) return '';

  const keyLooksUnset =
    !GEMINI_API_KEY || GEMINI_API_KEY.startsWith('PASTE_YOUR');
  if (keyLooksUnset) {
    console.warn('Gemini API key not set — speaking raw words instead.');
    return rawText;
  }

  const languageName = LANGUAGE_NAMES[languageCode] || 'English';

  const prompt = [
    `You are helping a Deaf person communicate. Below is a sequence of`,
    `individual signed words, detected one at a time and possibly out`,
    `of strict grammatical order. Turn them into one short, natural,`,
    `grammatically correct sentence in ${languageName}.`,
    ``,
    `Rules:`,
    `- Keep the original meaning and intent exactly — do not add`,
    `  information that wasn't implied by the words.`,
    `- Output ONLY the final sentence, nothing else (no quotes, no`,
    `  explanation, no labels).`,
    `- If the words don't form a clear sentence, output the most`,
    `  reasonable natural phrasing of them instead of guessing wildly.`,
    ``,
    `Words: ${words.join(', ')}`,
  ].join('\n');

  try {
    const response = await fetch(`${ENDPOINT(GEMINI_MODEL)}?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.3,
          maxOutputTokens: 100,
        },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.warn('Gemini request failed:', response.status, errText);
      return rawText;
    }

    const data = await response.json();
    const cleaned = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
    return cleaned || rawText;
  } catch (err) {
    console.warn('Gemini request error:', err?.message);
    return rawText;
  }
}

export default cleanUpSentence;
