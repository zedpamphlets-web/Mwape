import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LANGUAGES } from './translations';

const STORAGE_KEY = 'signspeak.language';

const LanguageContext = createContext({
  code: 'en',
  t: LANGUAGES[0].strings,
  setLanguage: () => {},
  languages: LANGUAGES,
});

export function LanguageProvider({ children }) {
  const [code, setCode] = useState('en');

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((saved) => {
      if (saved && LANGUAGES.some((l) => l.code === saved)) {
        setCode(saved);
      }
    });
  }, []);

  const setLanguage = async (newCode) => {
    setCode(newCode);
    await AsyncStorage.setItem(STORAGE_KEY, newCode);
  };

  const value = useMemo(() => {
    const active = LANGUAGES.find((l) => l.code === code) || LANGUAGES[0];
    return { code, t: active.strings, setLanguage, languages: LANGUAGES };
  }, [code]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage() {
  return useContext(LanguageContext);
}
