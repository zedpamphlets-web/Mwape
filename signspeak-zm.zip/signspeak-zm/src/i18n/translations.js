// SignSpeak ZM — translations
//
// IMPORTANT: English is fully translated and safe to ship.
// The 7 local languages below have only a small set of greeting words
// filled in where there is high confidence. Every other key currently
// falls back to English on purpose — DO NOT ship inaccurate guesses in
// an accessibility app. Before launch, have a native speaker of each
// language review and complete the "TODO" keys.
//
// Zambia's 7 officially recognised local languages + English = 8 total.

const en = {
  appName: 'SignSpeak',
  home: 'Home',
  settings: 'Settings',
  payment: 'Payment',
  welcomeTitle: 'Welcome to SignSpeak',
  welcomeBody: 'Sign in front of the camera. SignSpeak turns it into text, then speaks it out loud through your Bluetooth speaker.',
  startSigning: 'Start Signing',
  translating: 'Reading your sign…',
  detectedSign: 'Detected',
  noSignDetected: 'No sign detected yet',
  speakButton: 'Speak',
  cleaningUp: 'Tidying sentence…',
  replayButton: 'Replay',
  clearButton: 'Clear',
  selectLanguage: 'Select your language',
  cameraPermissionTitle: 'Camera access needed',
  cameraPermissionBody: 'SignSpeak needs your camera to see your signs.',
  grantPermission: 'Grant permission',
  bluetoothHint: 'Connect a Bluetooth speaker in your phone settings before speaking.',
  subscriptionTitle: 'SignSpeak Plans',
  subscriptionBody: 'Try free for 2 days, then pick a plan to keep going.',
  days: 'days',
  daysLeft: 'days left',
  trialActive: 'Free trial',
  planActive: 'Active plan',
  noAccess: 'Your access has ended — choose a plan below',
  trialEndedTitle: 'Your free trial has ended',
  trialEndedBody: 'Pick a plan to keep translating signs.',
  goToPayment: 'See plans',
  payWithMoney: 'Pay with Mobile Money',
  enterPhoneNumber: 'Enter your mobile money number',
  payNow: 'Pay Now',
  paymentProcessing: 'Processing payment…',
  paymentSuccess: 'Payment successful! Plan activated.',
  paymentFailed: 'Payment failed. Please try again.',
  cancel: 'Cancel',
};

// TODO(native-speaker-review): complete and verify every key below.
const bem = { // Bemba
  ...en,
  welcomeTitle: 'Mwaiseni ku SignSpeak',
};

const nya = { // Nyanja / Chewa
  ...en,
  welcomeTitle: 'Mwadzuka bwanji, tikulandirani ku SignSpeak',
};

const toi = { // Tonga
  ...en,
  welcomeTitle: 'Mwabuka buti, mwatambulwa ku SignSpeak',
};

const loz = { // Lozi
  ...en,
  welcomeTitle: 'Lumela, u amuhezwi kwa SignSpeak',
};

const kde = { // Kaonde
  ...en,
  welcomeTitle: 'Mwaiseni ku SignSpeak',
};

const lun = { // Lunda
  ...en,
  welcomeTitle: 'Mwaiseni ku SignSpeak',
};

const lue = { // Luvale
  ...en,
  welcomeTitle: 'Mwaiseni ku SignSpeak',
};

export const LANGUAGES = [
  { code: 'en', label: 'English', strings: en },
  { code: 'bem', label: 'Ichibemba (Bemba)', strings: bem },
  { code: 'nya', label: 'Chinyanja (Nyanja)', strings: nya },
  { code: 'toi', label: 'Chitonga (Tonga)', strings: toi },
  { code: 'loz', label: 'Silozi (Lozi)', strings: loz },
  { code: 'kde', label: 'Kikaonde (Kaonde)', strings: kde },
  { code: 'lun', label: 'Chilunda (Lunda)', strings: lun },
  { code: 'lue', label: 'Luvale', strings: lue },
];

export default LANGUAGES;
