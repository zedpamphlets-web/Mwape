// colors.js — glass UI design tokens.
//
// The look: a soft gradient backdrop behind frosted, translucent cards
// (via expo-blur's BlurView), thin light borders, and a single accent
// color used sparingly. See src/components/GlassCard.js for the
// reusable card that ties this together.

export default {
  // Background gradient (used with expo-linear-gradient on every screen)
  gradientStart: '#4E6BFF',
  gradientEnd: '#1B2A6B',

  // Accent
  primary: '#4E6BFF',
  primaryDark: '#2F46C7',

  // Text — designed to sit on the dark gradient background
  text: '#FFFFFF',
  textMuted: 'rgba(255,255,255,0.72)',
  textFaint: 'rgba(255,255,255,0.5)',

  // Glass surfaces
  glassFill: 'rgba(255,255,255,0.14)',
  glassFillStrong: 'rgba(255,255,255,0.22)',
  glassBorder: 'rgba(255,255,255,0.28)',

  // On-glass text (for light glass tiles, e.g. active states)
  onGlassText: '#1B2A6B',

  success: '#3DDC97',
  danger: '#FF6B6B',
  warning: '#FFB84D',
};
